import numpy as np
from skmultilearn.model_selection import IterativeStratification


def multilabel_fraction_indices(y, fraction: float, random_state: int = 42):
    """Return indices for an approximately stratified subset of a multi-label matrix.

    Parameters
    ----------
    y : np.ndarray of shape [n_samples, n_classes]
    fraction : float
        Fraction of examples to keep, e.g. 0.05, 0.10, 0.20, 0.50.
    random_state : int
        Included for API symmetry; IterativeStratification itself is deterministic
        for a given y ordering, so shuffle externally before calling if desired.
    """
    if not 0 < fraction <= 1:
        raise ValueError("fraction must be in (0, 1].")

    n_samples = y.shape[0]
    x_dummy = np.arange(n_samples).reshape(-1, 1)

    if fraction == 1.0:
        return np.arange(n_samples)

    n_splits = int(round(1 / fraction))
    if n_splits < 2:
        n_splits = 2

    dist = [fraction] + [(1 - fraction) / (n_splits - 1)] * (n_splits - 1)
    stratifier = IterativeStratification(n_splits=n_splits, order=1, sample_distribution_per_fold=dist)
    subset_idx, _ = next(stratifier.split(x_dummy, y))
    return subset_idx
