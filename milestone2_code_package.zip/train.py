import time
from typing import Dict, List

import numpy as np
import torch
from sklearn.metrics import average_precision_score, f1_score, hamming_loss


def make_optimizer(model, model_name: str, pretrained: bool):
    if not pretrained:
        lr = 1e-3 if "vit" in model_name or "deit" in model_name else 1e-2
        return torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    if "resnet" in model_name:
        backbone_params = []
        head_params = list(model.fc.parameters())
        head_ids = {id(p) for p in head_params}
        for p in model.parameters():
            if id(p) not in head_ids:
                backbone_params.append(p)
        return torch.optim.AdamW([
            {"params": backbone_params, "lr": 1e-4},
            {"params": head_params, "lr": 1e-3},
        ], weight_decay=1e-4)

    head_params = list(model.head.parameters())
    head_ids = {id(p) for p in head_params}
    backbone_params = [p for p in model.parameters() if id(p) not in head_ids]
    return torch.optim.AdamW([
        {"params": backbone_params, "lr": 1e-5},
        {"params": head_params, "lr": 1e-3},
    ], weight_decay=1e-4)


def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    total_loss = 0.0
    start = time.time()

    for images, labels in loader:
        images = images.to(device)
        labels = labels.to(device)

        optimizer.zero_grad()
        logits = model(images)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * images.size(0)

    return {
        "loss": total_loss / len(loader.dataset),
        "epoch_time_sec": time.time() - start,
    }


@torch.no_grad()
def evaluate(model, loader, criterion, device, threshold: float = 0.5) -> Dict[str, float]:
    model.eval()
    total_loss = 0.0
    all_probs: List[np.ndarray] = []
    all_labels: List[np.ndarray] = []
    start = time.time()

    for images, labels in loader:
        images = images.to(device)
        labels = labels.to(device)

        logits = model(images)
        loss = criterion(logits, labels)
        probs = torch.sigmoid(logits)

        total_loss += loss.item() * images.size(0)
        all_probs.append(probs.cpu().numpy())
        all_labels.append(labels.cpu().numpy())

    eval_time = time.time() - start
    all_probs = np.vstack(all_probs)
    all_labels = np.vstack(all_labels)
    preds = (all_probs >= threshold).astype(int)

    per_class_ap = []
    for c in range(all_labels.shape[1]):
        if all_labels[:, c].sum() > 0:
            per_class_ap.append(average_precision_score(all_labels[:, c], all_probs[:, c]))
        else:
            per_class_ap.append(np.nan)

    valid_ap = [x for x in per_class_ap if not np.isnan(x)]
    macro_f1 = f1_score(all_labels, preds, average="macro", zero_division=0)
    micro_f1 = f1_score(all_labels, preds, average="micro", zero_division=0)
    exact_match = float((preds == all_labels).all(axis=1).mean())

    return {
        "loss": total_loss / len(loader.dataset),
        "mAP": float(np.mean(valid_ap)) if valid_ap else float("nan"),
        "macro_f1": float(macro_f1),
        "micro_f1": float(micro_f1),
        "hamming_loss": float(hamming_loss(all_labels, preds)),
        "exact_match": exact_match,
        "per_class_ap": per_class_ap,
        "eval_time_sec": eval_time,
    }


def fit(model, train_loader, val_loader, optimizer, device, epochs=30, patience=5):
    criterion = torch.nn.BCEWithLogitsLoss()
    history = []
    best_map = -1.0
    best_state = None
    epochs_without_improve = 0

    for epoch in range(1, epochs + 1):
        train_metrics = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_metrics = evaluate(model, val_loader, criterion, device)
        record = {"epoch": epoch, **{f"train_{k}": v for k, v in train_metrics.items()}, **{f"val_{k}": v for k, v in val_metrics.items() if k != "per_class_ap"}}
        history.append(record)

        if val_metrics["mAP"] > best_map:
            best_map = val_metrics["mAP"]
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
            epochs_without_improve = 0
        else:
            epochs_without_improve += 1
            if epochs_without_improve >= patience:
                break

    return history, best_state
