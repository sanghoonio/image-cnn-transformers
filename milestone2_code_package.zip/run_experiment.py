import argparse
import json
import os

import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset

from dataset_verification import VOC_CLASSES
from models import build_deit_s, build_resnet50, build_vit_b16
from sampling import multilabel_fraction_indices
from train import fit, make_optimizer
from transforms_config import get_eval_transform, get_train_transform


class VOCDataset(Dataset):
    def __init__(self, df, image_root, transform=None):
        self.df = df.reset_index(drop=True)
        self.image_root = image_root
        self.transform = transform

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        image = Image.open(os.path.join(self.image_root, row["filename"])).convert("RGB")
        if self.transform:
            image = self.transform(image)
        labels = torch.tensor(row[VOC_CLASSES].values.astype("float32"))
        return image, labels


def load_split_df(voc_root: str, split: str) -> pd.DataFrame:
    main_dir = os.path.join(voc_root, "ImageSets", "Main")
    image_ids = None
    label_frames = []

    for cls in VOC_CLASSES:
        path = os.path.join(main_dir, f"{cls}_{split}.txt")
        df = pd.read_csv(path, sep=r"\s+", header=None, names=["image_id", "value"], engine="python")
        if image_ids is None:
            image_ids = df[["image_id"]].copy()
        label_frames.append((df["value"] == 1).astype(int).rename(cls))

    out = pd.concat([image_ids] + label_frames, axis=1)
    out["filename"] = out["image_id"].astype(str) + ".jpg"
    return out


def build_model(name: str, pretrained: bool):
    if name == "resnet50":
        return build_resnet50(pretrained=pretrained, num_classes=20)
    if name == "vit_b16":
        return build_vit_b16(pretrained=pretrained, num_classes=20)
    if name == "deit_s":
        return build_deit_s(pretrained=pretrained, num_classes=20)
    raise ValueError(f"Unknown model: {name}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--voc-root", required=True)
    parser.add_argument("--model", choices=["resnet50", "vit_b16", "deit_s"], default="resnet50")
    parser.add_argument("--pretrained", action="store_true")
    parser.add_argument("--data-fraction", type=float, default=1.0)
    parser.add_argument("--aug-policy", choices=["none", "standard", "strong"], default="standard")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out-dir", default="outputs")
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    train_df = load_split_df(args.voc_root, "train")
    val_df = load_split_df(args.voc_root, "val")

    y_train = train_df[VOC_CLASSES].values
    subset_idx = multilabel_fraction_indices(y_train, args.data_fraction)
    train_subset = train_df.iloc[subset_idx].reset_index(drop=True)

    image_root = os.path.join(args.voc_root, "JPEGImages")
    train_ds = VOCDataset(train_subset, image_root, transform=get_train_transform(args.aug_policy))
    val_ds = VOCDataset(val_df, image_root, transform=get_eval_transform())

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=2)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=2)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_model(args.model, args.pretrained).to(device)
    optimizer = make_optimizer(model, args.model, args.pretrained)

    history, best_state = fit(model, train_loader, val_loader, optimizer, device, epochs=args.epochs, patience=5)

    os.makedirs(args.out_dir, exist_ok=True)
    run_name = f"{args.model}_pre{int(args.pretrained)}_frac{args.data_fraction}_aug{args.aug_policy}_seed{args.seed}"
    with open(os.path.join(args.out_dir, f"{run_name}_history.json"), "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2)

    if best_state is not None:
        torch.save(best_state, os.path.join(args.out_dir, f"{run_name}_best.pt"))

    print(f"Saved outputs to {args.out_dir}")


if __name__ == "__main__":
    main()
