# Milestone II Starter Code

This package provides a reproducible starter framework for the DS 6050 Group 8 Milestone II project on CNNs vs. Vision Transformers for multi-label image classification on PASCAL VOC.

## Included
- `dataset_verification.py`: builds a VOC label table and prints dataset summary statistics
- `sampling.py`: iterative multi-label stratification helpers
- `models.py`: ResNet-50, ViT-B/16, and DeiT-S builders
- `train.py`: training and evaluation loops for multi-label classification
- `run_experiment.py`: command-line entry point for a single run
- `transforms_config.py`: no / standard / strong augmentation policies
- `requirements.txt`: Python dependencies

## Suggested first runs
1. Pretrained ResNet-50 on 100% data
2. Pretrained ViT-B/16 on 100% data
3. Scratch ResNet-50 on 100% data
4. Scratch ViT-B/16 on 100% data
5. Pretrained ResNet-50 and ViT-B/16 on 10% and 5% data

## Notes
- Update `VOC_ROOT` in `run_experiment.py` or pass it via `--voc-root`.
- This code assumes VOC-style folder structure with `JPEGImages/` and `ImageSets/Main/`.
- Replace placeholder comments with your team-specific logging, checkpointing, and plotting preferences.
