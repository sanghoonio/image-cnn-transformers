import timm
import torch.nn as nn
import torchvision.models as tv_models


def build_resnet50(pretrained: bool = True, num_classes: int = 20):
    weights = tv_models.ResNet50_Weights.IMAGENET1K_V2 if pretrained else None
    model = tv_models.resnet50(weights=weights)
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    return model


def build_vit_b16(pretrained: bool = True, num_classes: int = 20):
    model = timm.create_model("vit_base_patch16_224", pretrained=pretrained)
    model.head = nn.Linear(model.head.in_features, num_classes)
    return model


def build_deit_s(pretrained: bool = True, num_classes: int = 20):
    model = timm.create_model("deit_small_patch16_224", pretrained=pretrained)
    model.head = nn.Linear(model.head.in_features, num_classes)
    return model
