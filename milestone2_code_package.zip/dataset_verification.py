import argparse
import json
import os
from collections import OrderedDict

import pandas as pd

VOC_CLASSES = [
    "aeroplane", "bicycle", "bird", "boat", "bottle",
    "bus", "car", "cat", "chair", "cow",
    "diningtable", "dog", "horse", "motorbike", "person",
    "pottedplant", "sheep", "sofa", "train", "tvmonitor",
]


def _load_split_labels(voc_root: str, split: str) -> pd.DataFrame:
    main_dir = os.path.join(voc_root, "ImageSets", "Main")
    image_ids = None
    label_frames = []

    for cls in VOC_CLASSES:
        path = os.path.join(main_dir, f"{cls}_{split}.txt")
        df = pd.read_csv(path, sep=r"\s+", header=None, names=["image_id", "value"], engine="python")
        if image_ids is None:
            image_ids = df[["image_id"]].copy()
        label_frames.append((df["value"] == 1).astype(int).rename(cls))

    labels = pd.concat([image_ids] + label_frames, axis=1)
    labels["filename"] = labels["image_id"].astype(str) + ".jpg"
    return labels


def summarize_split(df: pd.DataFrame) -> OrderedDict:
    label_counts = df[VOC_CLASSES].sum(axis=0).to_dict()
    labels_per_image = df[VOC_CLASSES].sum(axis=1)
    summary = OrderedDict()
    summary["num_images"] = int(len(df))
    summary["avg_labels_per_image"] = float(labels_per_image.mean())
    summary["pct_images_gt1_label"] = float((labels_per_image > 1).mean() * 100)
    summary["min_class_count"] = int(min(label_counts.values()))
    summary["max_class_count"] = int(max(label_counts.values()))
    summary["class_counts"] = label_counts
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--voc-root", required=True, help="Path to VOCdevkit/VOC2012")
    parser.add_argument("--out-json", default=None)
    args = parser.parse_args()

    train_df = _load_split_labels(args.voc_root, "train")
    val_df = _load_split_labels(args.voc_root, "val")

    result = {
        "classes": VOC_CLASSES,
        "train": summarize_split(train_df),
        "val": summarize_split(val_df),
    }

    print(json.dumps(result, indent=2))
    if args.out_json:
        with open(args.out_json, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
